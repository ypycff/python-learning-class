def proc8(value):
    print("In proc8 with value %s" % value)

def proc9(value):
    print("In proc9 with value %s" % value)

def proc35(value):
    print("In proc35 with value %s" % value)
	
def proc_other(value):
    print("In proc_other with value %s" % value)
